package com.cg.demomvc;

import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {
		
		
		ApplicationContext factory = SpringApplication.run(Client.class, args);
		User user = (User) factory.getBean("user");
		System.out.println(user.getUserId());
		System.out.println(user.getUserName());
		System.out.println(user.getPassword());

	}

}
