package com.cg.demo;

public interface CurrencyConverter {
	public double dollarToRupees(double dollars);
}
