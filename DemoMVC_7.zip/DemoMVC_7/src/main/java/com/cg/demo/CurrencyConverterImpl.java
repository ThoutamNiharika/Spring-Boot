package com.cg.demo;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CurrencyConverterImpl implements CurrencyConverter {
	@Autowired
	private ExchangeServiceImpl exchangeService;

	@PostConstruct
	public void customInit() {
		System.out.println("In customInit in CurrrencyConverter class");
	}

	@PreDestroy
	public void customDestroy() {
		System.out.println("In customDestroy() in CurrrencyConverter class");
	}
	
	@Autowired
	public CurrencyConverterImpl(ExchangeServiceImpl exchangeService) {
		System.out.println("in Constructor");
		this.exchangeService = exchangeService;
	}

	

	public ExchangeServiceImpl getExchangeService() {
		System.out.println("getExchangeService()");
		return exchangeService;
	}

	
	public void setExchangeService(ExchangeServiceImpl exchangeService) {
		System.out.println("setExchangeService()");
		this.exchangeService = exchangeService;
	}

	public CurrencyConverterImpl() {

		System.out.println("CurrencyConverterImpl");

	}
	public double dollarToRupees(double dollars) {
		System.out.println("dollarToRupees");
		return dollars * exchangeService.getExchangeRate();
	}
	
}
