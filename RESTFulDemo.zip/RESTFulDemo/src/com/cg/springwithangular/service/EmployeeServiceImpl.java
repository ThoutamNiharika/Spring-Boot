package com.cg.springwithangular.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springwithangular.beans.Employee;
import com.cg.springwithangular.dao.IEmployeeDAO;

@Service("empservice")
public class EmployeeServiceImpl implements IEmployeeService {

	@Autowired
	IEmployeeDAO empDao;
	@Override
	public List<Employee> getAllEmployee() {
		return empDao.getAllEmployee();
	}

	@Override
	public void addEmployee(Employee emp) {
		empDao.addEmployee(emp);
	}

	@Override
	public void deleteEmployee(int id) {
		empDao.deleteEmployee(id);
	}

	@Override
	public Employee searchEmployee(int id) {
		return empDao.searchEmployee(id);
	}

	@Override
	public void updateEmployee(Employee emp) {
		empDao.updateEmployee(emp);
	}

}
